# Created by 'jpyutil.py' tool on 2022-02-07 17:54:39.825324
# This file is read by the 'jpyutil' module in order to load and configure the JVM from Python
java_home = '/usr/lib/jvm/java-8-openjdk-amd64/'
jvm_dll = '/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/amd64/server/libjvm.so'
jvm_maxmem = None
jvm_classpath = []
jvm_properties = {}
jvm_options = []
