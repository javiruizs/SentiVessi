# Created by 'jpyutil.py' tool on 2021-07-07 21:02:58.072816
# This file is read by the 'jpyutil' module in order to load and configure the JVM from Python
java_home = 'C:\\Program Files\\Java\\jdk-11.0.11'
jvm_dll = 'C:\\Program Files\\Java\\jdk-11.0.11\\bin\\server\\jvm.dll'
jvm_maxmem = None
jvm_classpath = []
jvm_properties = {}
jvm_options = []
